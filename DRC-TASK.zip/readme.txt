step - 1

install node modul

step - 2

json server start port 5000
