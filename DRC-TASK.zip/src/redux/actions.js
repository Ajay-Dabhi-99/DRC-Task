import axios from "axios";

// user-wise Todo
export const fetchTodos = (userId) => async (dispatch) => {
  try {
    const response = await axios.get(
      `http://localhost:5000/todos?userId=${userId}`
    );
    dispatch({ type: "FETCH_TODOS_SUCCESS", payload: response.data });
  } catch (error) {
    console.log("Error fetching todos:", error);
  }
};

// Add new Todo
export const addTodo =
  (userId, title, description, date) => async (dispatch) => {
    try {
      const response = await axios.post("http://localhost:5000/todos", {
        userId,
        title,
        description,
        date,
      });
      dispatch({ type: "ADD_TODO_SUCCESS", payload: response.data });
    } catch (error) {
      console.log("Error adding todo:", error);
    }
  };

// Delete Todo
export const deleteTodo = (id) => async (dispatch) => {
  try {
    await axios.delete(`http://localhost:5000/todos/${id}`);
    dispatch({ type: "DELETE_TODO_SUCCESS", payload: id });
  } catch (error) {
    console.log("Error deleting todo:", error);
  }
};
