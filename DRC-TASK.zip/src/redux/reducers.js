const initialState = {
  todos: [],
};

const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    // fetch Todo
    case "FETCH_TODOS_SUCCESS":
      return {
        ...state,
        todos: action.payload,
      };
    // Add Todo case
    case "ADD_TODO_SUCCESS":
      return {
        ...state,
        todos: [...state.todos, action.payload],
      };
    // Delete Case
    case "DELETE_TODO_SUCCESS":
      return {
        ...state,
        todos: state.todos.filter((todo) => todo.id !== action.payload),
      };
    default:
      return state;
  }
};

export default rootReducer;
