import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addTodo } from "../redux/actions";
import { useNavigate } from "react-router-dom";

const AddTodo = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [newTodo, setNewTodo] = useState({
    title: "",
    description: "",
    date: "",
  });

  const handelTodo = (field, value) => {
    setNewTodo({ ...newTodo, [field]: value });
  };

  const userId = sessionStorage.getItem("userID");
  newTodo.date = new Date();
  const handleAddTodo = () => {
    dispatch(addTodo(userId,newTodo.title,newTodo.description,newTodo.date));
    navigate("../dashboard");
  };

  return (
    <>
      <div className="flex items-center h-screen">
        <div className="max-w-lg  mx-auto flex items-center justify-center w-full flex-wrap bg-white border border-[#E2E8F0] rounded-xl shadow-lg ">
          <form className="w-full space-y-5 p-5">
            <h1 className="text-4xl text-[#1E293B] font-bold text-center pb-5">
              Add Todo
            </h1>
            <div>
              <label
                htmlFor=""
                className="block text-sm text-[#1E293B] font-bold pb-1"
              >
                Title
              </label>
              <input
                type="text"
                value={newTodo.title}
                name="title"
                onChange={(e) => handelTodo("title",e.target.value)}
                className="flex items-center w-full bg-transparent p-3.5 py-[13px] outline-none border border-[#E2E8F0] rounded-xl placeholder:text-[#94A3B8] placeholder:text-base"
                placeholder="Enter Title"
                required
              />
            </div>
            <div>
              <label
                htmlFor=""
                className="block text-sm text-[#1E293B] font-bold pb-1"
              >
                Description
              </label>
              <textarea
                type="text"
                value={newTodo.description}
                name="description"
                onChange={(e) => handelTodo("description",e.target.value)}
                className="flex items-center w-full bg-transparent p-3.5 py-[13px] outline-none border border-[#E2E8F0] rounded-xl placeholder:text-[#94A3B8] placeholder:text-base"
                placeholder="Enter Description"
                required
              />
            </div>
            <button
              type="submit"
              onClick={handleAddTodo}
              className="w-full block bg-[#C8EE44] text-[#1E293B] border-[#C8EE44] border hover:bg-[#78970D] hover:text-white hover:border-[#78970D] px-5 md:px-6 py-2 md:py-3 text-xs md:text-sm font-bold transition-all duration-300 rounded-[10px] w-ful uppercase leading-7 "
            >
              Add
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddTodo;
