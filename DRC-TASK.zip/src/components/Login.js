import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { fetchTodos } from "../redux/actions";
import { useDispatch } from "react-redux";

function Login() {
  const [userData, setUserData] = useState({ email: "", password: "" });
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLoginData = (field, value) => {
    setUserData({ ...userData, [field]: value });
  };

  // Login User
  const handleLogin = (e) => {
    e.preventDefault();
    if (userData && userData.email && userData.password !== "") {
      fetch("http://localhost:5000/users")
        .then((response) => response.json())
        .then((data) => {
          console.log("data", data);
          const foundUser = data.find(
            (user) =>
              user.username === userData.username &&
              user.password === userData.password
          );
          if (foundUser) {
            dispatch(fetchTodos(foundUser.id));
            sessionStorage.setItem("user", foundUser.email);
            sessionStorage.setItem("userID",foundUser.id);
            navigate("../dashboard");
            toast.success("Login successful!");
          } else {
            toast.error("Invalid username or password");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    } else {
      toast.error("Email or password is Required");
    }
  };


  // If user Not Logout
  const PrivetRout = sessionStorage.getItem("user");
  useEffect(() => {
    if ((PrivetRout && PrivetRout !== "") || null || undefined) {
      navigate("../dashboard");
    } else {
      navigate("../ ");
    }
  }, [PrivetRout]);

  return (
    <div className="flex items-center h-screen">
      <div className="max-w-lg mx-auto flex items-center justify-center h-full max-h-[400px] w-full flex-wrap bg-white border border-[#E2E8F0] rounded-xl shadow-lg ">
        <form className="w-full space-y-5 p-5">
          <h1 className="text-4xl text-[#1E293B] font-bold text-center pb-5">
            Login
          </h1>
          <div>
            <label
              htmlFor=""
              className="block text-sm text-[#1E293B] font-bold pb-1"
            >
              Email or Phone
            </label>
            <input
              type="text"
              name="username"
              value={userData.email}
              onChange={(e) => {
                handleLoginData("email", e.target.value);
              }}
              className="flex items-center w-full bg-transparent p-3.5 py-[13px] outline-none border border-[#E2E8F0] rounded-xl placeholder:text-[#94A3B8] placeholder:text-base"
              placeholder="Enter your email"
              required
            />
          </div>
          <div>
            <label
              htmlFor=""
              className="block text-sm text-[#1E293B] font-bold pb-1"
            >
              Password
            </label>
            <input
              type="Password"
              name="Password"
              value={userData.password}
              onChange={(e) => {
                handleLoginData("password", e.target.value);
              }}
              placeholder="Enter your password"
              className="flex items-center w-full bg-transparent p-3.5 py-[13px] outline-none border border-[#E2E8F0] rounded-xl placeholder:text-[#94A3B8] placeholder:text-base"
              required
            />
          </div>
          <button
            type="submit"
            onClick={handleLogin}
            className="w-full block bg-[#C8EE44] text-[#1E293B] border-[#C8EE44] border hover:bg-[#78970D] hover:text-white hover:border-[#78970D] px-5 md:px-6 py-2 md:py-3 text-xs md:text-sm font-bold transition-all duration-300 rounded-[10px] w-ful uppercase leading-7 "
          >
            Sign in
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
